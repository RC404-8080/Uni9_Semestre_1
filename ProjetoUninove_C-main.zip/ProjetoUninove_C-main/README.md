# ProjetoUninove_C

Projeto em C feito no meu 1º semestre em grupo de 4 alunos para simular app de cadastro de pedidos (a ideia é uma aplicação de uma pastelaria que possa cadastrar usuarios(para agilizar em pedidos futuros), salvar informações do pedido em ordem de chegada(pensando no envio da comida) e mais algumas outras funções).

Espero que gostem 😅.
